package ru.aplana.autotests.pages;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.webdriver.ThucydidesWebDriverSupport;
import org.openqa.selenium.WebElement;
import ru.aplana.autotests.pages.base.BasePage;

public class CatalogPage extends BasePage {

    @FindBy(xpath="//input[@id='glf-pricefrom-var']")
    private WebElement priceFrom;

    @FindBy(xpath="//div[@class='n-filter-panel-aside__apply']/button")
    private WebElement applySearchFormButton;

    public String clickToApplySearchFormButton(){
        if(applySearchFormButton.isDisplayed()){
            applySearchFormButton.click();
            return "Кнопка подтверждения расширенного поиска успешно нажата.";
        } else{
            return "Кнопка подтверждения расширенного поиска не нажата, возможно элемент не определён.";
        }
    }

    public void setMinimumPrice(int price){
        priceFrom.sendKeys(price + "");
    }

    public void setCompanyCheckbox(String linkName){
            ThucydidesWebDriverSupport.getDriver().findElement(By.xpath("//span[contains(@class,'checkbox')]/label[text()='" + linkName + "']")).click();
    }

    public void setCompanyListByParam(String cList){
        for(String name : cList.split(",")){
            this.setCompanyCheckbox(name);
        }
    }
}