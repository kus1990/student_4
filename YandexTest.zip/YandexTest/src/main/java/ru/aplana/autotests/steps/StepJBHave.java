package ru.aplana.autotests.steps;

import net.thucydides.core.annotations.Steps;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class StepJBHave {

    @Steps
    MainPageSteps mainSteps;

    @Given("перейти на $pageurl")
    public void goToMainPage(String pageUrl){
        mainSteps.setUpBrowser(pageUrl);
    }

    @When("перейти в яндекс маркет")
    public void goToMarketStory(){
        mainSteps.goToMarketPage();
    }

    @When("выбрать раздел $linkn")
    public void goToComplexPartStory(String linkn){
        mainSteps.clickToMainMenuPart(linkn);
    }

    @When("выбрать подраздел $linkn")
    public void goToComplexSubPart(String linkn){
        mainSteps.clickToSubMenuPart(linkn);
    }

    @When("задать минимальную стоимость $mprice")
    public void setMinPriceStory(int mprice){
        mainSteps.setMinimumPriceStory(mprice);
    }

    @When("выбрать компании для поиска: $clist")
    public void setCompanyeListStory(String cList){
        mainSteps.setCompanyList(cList);
    }

    @When("нажать кнопку применить")
    public void goToSearchResultStory(){
        mainSteps.goToSearchResult();
    }

    @Then("проверить количество элементов каталоге: $count")
    public void chekElCountStory(int count){
        mainSteps.checkItemsCount(count);
    }

    @When("запомнить $elindex элемент в каталоге")
    public void storeFirstElementStory(int elindex){
        mainSteps.storeElementHeader(elindex);
    }

    @When("ввести в поисковую строку запомненное значение и нажать кнопку найти")
    public void setSearchStringStory(){
        mainSteps.setSearchString();
    }

    @Then("проверить наименование товара")
    public void checkItemHeaderStory(){
        mainSteps.checkItemHeader();
    }
}
