package ru.aplana.autotests.pages;
import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.webdriver.ThucydidesWebDriverSupport;
import ru.aplana.autotests.pages.base.BasePage;

public class MarketPage extends BasePage {

    public void clickToMainMenuByParams(String linkName){
            ThucydidesWebDriverSupport.getDriver().findElement(By.xpath("//li[@data-department = '" + linkName + "']/a")).click();
    }

    public void clickToSubMenuByParams(String linkName){
            ThucydidesWebDriverSupport.getDriver().findElement(By.xpath("//div[@class='catalog-menu__list']/a[text()='" + linkName + "']")).click();
    }
}
