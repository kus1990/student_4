package ru.aplana.autotests.pages;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.webdriver.ThucydidesWebDriverSupport;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import ru.aplana.autotests.pages.base.BasePage;

import java.util.List;

public class ItemListPage extends BasePage {

    @FindBy(xpath="//div[contains(@class,'snippet-list')]/div[contains(@class,'n-snippet-card')]")
    private List<WebElement> itemList;

    @FindBy(xpath="//input[@id='header-search']")
    private WebElement searchField;

    @FindBy(xpath="//form[contains(@class,'header2__search')]//button")
    private WebElement searchButton;

    private String actualHeaderText;

    public void checkItemsListSize(int cnt){
        Assert.assertEquals("Получено некоррекстное количество элементов.", cnt, itemList.size());
    }

    public String getActualHeader(){
        return actualHeaderText;
    }

    public void clickSearchButton(){ searchButton.click(); }

    public void storeHeaderText(int elementIndex){
        actualHeaderText = ThucydidesWebDriverSupport.getDriver().findElement(By.xpath("(//div[contains(@class,'snippet-list')]/div[contains(@class,'n-snippet-card')])[" + elementIndex +"]//span[@class='snippet-card__header-text']")).getText();
    }

    public void searchStoredHeader(){
        searchField.sendKeys(actualHeaderText);
        this.clickSearchButton();
    }

}