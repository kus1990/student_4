package ru.aplana.autotests.steps;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.webdriver.ThucydidesWebDriverSupport;
import ru.aplana.autotests.pages.*;
import java.io.File;
import java.util.concurrent.TimeUnit;

public class MainPageSteps {

    MainPage mainPage;
    SingleItem singleItem;
    MarketPage marketPage;
    ItemListPage itemListPage;
    CatalogPage catalogPage;

    @Step("Открыта главная страница {0}")
    public void setUpBrowser(String browserUrl){
       String workingDir = System.getProperty("user.dir");
       System.setProperty("webdriver.firefox.marionette", workingDir + File.separator + "drivers" + File.separator +"geckodriver");
       ThucydidesWebDriverSupport.getDriver().manage().window().maximize();
       ThucydidesWebDriverSupport.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       ThucydidesWebDriverSupport.getDriver().get(browserUrl);
    }

    @Step("Перейти в яндекс маркет")
    public void goToMarketPage(){
        mainPage.clickToMarketPart();
    }

    @Step("Выбрать раздел {0}")
    public void clickToMainMenuPart(String linkName){
        marketPage.clickToMainMenuByParams(linkName);
    }

    @Step("Выбрать подраздел {0}")
    public void clickToSubMenuPart(String linkName){
        marketPage.clickToSubMenuByParams(linkName);
    }

    @Step("Задать минимальную стоимость {0}")
    public void setMinimumPriceStory(int price){
        catalogPage.setMinimumPrice(price);
    }

    @Step("Выбрать компании для поиска: {0}")
    public void setCompanyList(String cList){
        catalogPage.setCompanyListByParam(cList);
    }

    @Step("Нажать кнопку применить")
    public void goToSearchResult(){
        catalogPage.clickToApplySearchFormButton();
    }

    @Step("Проверить количество элементов:{0}")
    public void checkItemsCount(int elCount){ itemListPage.checkItemsListSize(elCount); }

    @Step("Запомнить {0} элемент в списке")
    public void storeElementHeader(int elindex){
        itemListPage.storeHeaderText(elindex);
    }

    @Step("Ввести в поисковую строку запомненное значение")
    public void setSearchString(){
        itemListPage.searchStoredHeader();
    }

    @Step("Проверить наименование товара")
    public void checkItemHeader(){
        singleItem.checkHeader(itemListPage.getActualHeader());
    }
}
