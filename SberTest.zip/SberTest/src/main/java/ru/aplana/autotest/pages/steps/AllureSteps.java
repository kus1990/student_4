package ru.aplana.autotest.pages.steps;

import org.openqa.selenium.WebDriver;
import ru.aplana.autotest.pages.pages.CreditCalculatePage;
import ru.aplana.autotest.pages.pages.HomePage;
import ru.yandex.qatools.allure.annotations.Step;

public class AllureSteps {

    private WebDriver driver;


    public AllureSteps(WebDriver driver) {
        this.driver = driver;
    }

    @Step
    public void openMainPage() {
        driver.get("http://www.sberbank.ru");
    }

    @Step
    public void clickToCvartPart(WebDriver driver,HomePage mainPage) {
        mainPage.clickToCvartPart(driver);
    }

    @Step
    public void setFormData(WebDriver driver,String argx,String argy,String argz,String arga,String argb,String argc,CreditCalculatePage calcPage) {
        calcPage.complexSelectClick("Тип расчета",argx,driver);
        calcPage.complexSelectClick("Первоначальный взнос",argy,driver);
        calcPage.complexSelectClick("Срок кредитования",argz,driver);
        calcPage.complexSelectClick("Категория заемщика",arga,driver);
        calcPage.setGender(argb,driver);
        calcPage.setProfitNum(argc);
    }

    @Step
    public void applyForm(WebDriver driver,CreditCalculatePage calcPage) {
        calcPage.applyForm();
    }

    @Step
    public void checkTableData(WebDriver driver,String argx,String argy,String argz,String arga,String argb,String argc,CreditCalculatePage calcPage) {
        calcPage.checkComplexTableInput("Срок кредита",argx,driver);
        calcPage.checkSimpleTableInput("Сумма кредита",argy,driver);
        calcPage.checkComplexTableInput("Ставка",argz,driver);
        calcPage.checkUniTableInput("Ежемесячный платеж",arga,driver);
        calcPage.checkSimpleTableInput("Начало выплат",argb,driver);
        calcPage.checkSimpleTableInput("Окончание выплат",argc,driver);
    }


}
