package ru.aplana.autotest.pages.pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreditCalculatePage extends BasePage
{
    @FindBy(xpath="//span[text()='Основной доход']/ancestor::div[2]//input[@class='form_input_text']")
    public WebElement profitInput;

    @FindBy(xpath="//div[contains(@class,'white-form-widget')]//button[text()='Рассчитать погашение']")
    public WebElement applyFormLink;


    public void complexSelectClick(String labelName, String text,WebDriver driver){
        driver.findElement(By.xpath("//span[text()='" + labelName +"']/ancestor::div[2]/div/div")).click();
        driver.findElement(By.xpath("//div[contains(text(),'" + text +"')]")).click();
    }

    public void setGender(String labelName,WebDriver driver){
        driver.findElement(By.xpath("//label[@label='" + labelName +"']/parent::span")).click();
    }

    public void setProfitNum(String profit){
        profitInput.sendKeys(profit);
    }

    public void applyForm(){
        applyFormLink.click();
    }

    public void checkSimpleTableInput(String inputName,String value,WebDriver driver){
        WebElement checkField = driver.findElement(By.xpath("//td[text()='"+ inputName +"']/parent::tr/td[2]"));
        Assert.assertEquals("Не совпадает значение.", value, checkField.getText());
    }

    public void checkComplexTableInput(String inputName,String value,WebDriver driver){
        WebElement checkField = driver.findElement(By.xpath("//td[text()='"+ inputName +"']/parent::tr/td[2]/span[1]"));
        Assert.assertEquals("Не совпадает значение.", value, checkField.getText());
    }

    public void checkUniTableInput(String inputName,String value,WebDriver driver){
        WebElement checkField = driver.findElement(By.xpath("//span[text()='"+ inputName +"']/parent::td/parent::tr/td[2]/span[1]"));
        Assert.assertEquals("Не совпадает значение.", value, checkField.getText());
    }

}
