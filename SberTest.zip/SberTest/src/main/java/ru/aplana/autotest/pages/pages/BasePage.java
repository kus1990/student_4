package ru.aplana.autotest.pages.pages;

import org.openqa.selenium.support.PageFactory;

public class BasePage extends PageFactory {

}
