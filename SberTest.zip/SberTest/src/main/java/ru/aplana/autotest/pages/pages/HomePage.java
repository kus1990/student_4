package ru.aplana.autotest.pages.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {
    
    @FindBy(xpath = "//ul[@class='alt-menu-list']//a[text()='Приобретение готового жилья']")
    public WebElement homeLink;

    @FindBy(xpath = "(//ul[@class='alt-menu-top-list'])[1]/li[1]")
    public WebElement creditLink;

    public void clickToCvartPart(WebDriver driver){
        Actions action = new Actions(driver);
        action.moveToElement(creditLink).perform();
        homeLink.click();
    }
}
