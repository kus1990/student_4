import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import ru.aplana.autotest.pages.pages.CreditCalculatePage;
import ru.aplana.autotest.pages.pages.HomePage;
import ru.aplana.autotest.pages.steps.AllureSteps;

import java.util.concurrent.TimeUnit;

public class TestClass {

    WebDriver driver;
    HomePage mainPage;
    CreditCalculatePage calcPage;
    private AllureSteps steps;

    @Before
    public void setUp() throws Exception {
        String workingDir = System.getProperty("user.dir");
        System.setProperty("webdriver.firefox.marionette", workingDir + "/drivers/geckodriver");
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        steps = new AllureSteps(driver);
    }

    @Test
    public void runTest() throws Exception {
        steps.openMainPage();
        mainPage = PageFactory.initElements(driver, HomePage.class);
        steps.clickToCvartPart(driver,mainPage);
        calcPage = PageFactory.initElements(driver, CreditCalculatePage.class);
        steps.setFormData(driver,"По среднемесячному доходу","от 50%","5 лет","Общие условия","Муж","100000",calcPage);
        steps.applyForm(driver,calcPage);
        steps.checkTableData(driver,"60","3 600 000","11.5","79 173,39","03 января 2017","03 декабря 2021",calcPage);
    }

    @After
    public void tearDown() throws Exception {
        driver.close();
    }
}
